import React from "react";

const About = () => {
    return (
        <>About</>
    )
}

export default About;